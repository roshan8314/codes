import java.util.*;
public class Function{
public static double calculateAverage(int a,int b,int c){
    double sum = 0;
    sum = a + b+ c;
    double average = sum/2;
    return average;
}

public static void main(String arge[]){
    Scanner sc = new Scanner(System.in);
    int a = sc.nextInt();
    int b = sc.nextInt();
    int c = sc.nextInt();
    double average = calculateAverage(a,b,c);
    System.out.print("Average of the number" + average);
    
}
}