/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.


*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	
	    int input;
	    do{
	        int marks = sc.nextInt();
	        if(marks >= 90 && marks <=100){
	            System.out.println("This is Good");
	        }else if(marks >=60 && marks <=89) {
	            System.out.println("This is also good");
	        }else if(marks >=0 && marks <=59){
	            System.out.println("This is good as well");
	        }else{
	            System.out.println("Invalid");
	        }
	        
	        System.out.println("Want to continue ? (yes(1) or no(2)");
	        input = sc.nextInt();
	    }while(input == 1);
	}
}
